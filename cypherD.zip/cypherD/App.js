import React from 'react';
import {
    StyleSheet,
    Text,
    View,
    ScrollView,
    StatusBar,
  } from 'react-native';
  
import HomeItem from 'D:/React native/cypherD/components/Home/home';
import SeedPhrase from 'D:/React native/cypherD/components/seedPhrase/index.js'

export default function Home ({navigation}) {
    return(
        <View style={styles.container}>
            <ScrollView>
                <HomeItem />
                <SeedPhrase/>
                <SeedPhrase/>
            </ScrollView>
            
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      flexDirection: 'column',
      backgroundColor: '#fff',
      margin: 20,
      padding: 20
    },
    
  });