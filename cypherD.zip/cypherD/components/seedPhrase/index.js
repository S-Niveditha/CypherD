import React from 'react';
import { StyleSheet, View, Text, StatusBar, Image, Pressable } from 'react-native';
import styles from './style';
import { StackNavigation } from 'react-navigation';

const SeedPhrase = (props) =>{
    return (
        <View>
            <Text style={[styles.mainText]}>Seed Phrase{"\n"}</Text>
            <Text style={styles.helpText}> Your seed phrase makes it easy to backup and restore your account</Text>
            <Text style={styles.hintText}> WARNING:</Text>
            <Pressable><Image 
                source={require('D:/React native/cypherD/assets/hide.png')} 
                style={ styles.image}
                onPress={()=> {console.warn('ICON PRESSED')}}
            />
            
            </Pressable>

            <Pressable
                style={[styles.button, {backgroundColor: 'yellow'}]}
                onPress={() => {console.warn("CONDIRMED")}}
            >
                <Text>CONFIRM</Text>
            </Pressable>
        </View>
    );
};

export default SeedPhrase;