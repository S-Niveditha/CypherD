import { StyleSheet, Dimensions } from 'react-native';

const styles = StyleSheet.create({
    mainText: {
        fontSize: 25,
        fontWeight: '500',
        textAlign: 'center',
        color: 'grey',
        fontWeight: 'bold'
        
      },
      helpText: {
        fontSize: 16,
        textAlign: 'center',
        marginTop: 10,
        color: 'grey'
      },
      hintText: {
        fontSize: 16,
        textAlign: 'center',
      },

      image:{
        marginTop: 40,
        width: 20,
        height: 20,
        justifyContent: "flex-end"
      }, 

      body:{
        marginTop: -40,
        textAlign: 'right',
        paddingLeft: 20,
        fontSize: 16,
      },

      button:{
        marginTop: 400,
        padding: 10,
        borderRadius: 25,
        width:'100%',
        height: 40,
        justifyContent: 'center',
        alignItems: 'center'
      }
});

export default styles;