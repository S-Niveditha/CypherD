import React from 'react';
import { StyleSheet, View, Text, StatusBar, Image, Pressable } from 'react-native';
import styles from './style';
import { createStackNavigator, createAppContainer } from 'react-navigation';

const HomeItem = (props) =>{

    return (
        <View>
        <Text numberOfLines={2} style={styles.mainText}>Get the world's first non- custodial cypher card</Text>
            <Text style={styles.helpText}>
              {"\n"}
              Explore all of web3 in one page
            </Text>
            <View>
                <Image 
                    source={require('D:/React native/cypherD/assets/swap.png')}
                    style={styles.image}   />
                <Text   
                    style={styles.body}>Swap to get instant USD</Text>
                <StatusBar style="auto" />
                <Image 
                    source={require('D:/React native/cypherD/assets/buy.png')}
                    style={styles.image}   />
                <Text   
                    style={styles.body}>Swap to get instant USD</Text>
                <StatusBar style="auto" />
                <Image 
                    source={require('D:/React native/cypherD/assets/chain.png')}
                    style={styles.image}   />
                <Text   
                    style={styles.body}>Swap to get instant USD</Text>
                <StatusBar style="auto" />
                <Image 
                    source={require('D:/React native/cypherD/assets/browser.png')}
                    style={styles.image}   />
                <Text   
                    style={styles.body}>Swap to get instant USD</Text>
                <StatusBar style="auto" />
                </View>

                <View>
                    <Pressable
                        style={[styles.button, {backgroundColor: 'yellow'}]}
                        onPress={() => {console.warn('PRESSED')}}
                    >
                        <Text style={{color: 'black'}}> CREATE NEW WALLET</Text>
                    </Pressable>

                    <Pressable
                        style={[styles.button, {backgroundColor: 'grey'}]}
                        onPress={() => {console.warn('PRESSED')}}
                    >
                        <Text style={{color: 'black'}}> IMPORT EXISTING WALLET</Text>
                    </Pressable>
                </View>
            </View>
    );
};

export default HomeItem;

