import { StyleSheet, Dimensions } from 'react-native';

const styles = StyleSheet.create({
    mainText: {
        fontSize: 25,
        fontWeight: '500',
        textAlign: 'left',
        
      },
      helpText: {
        fontSize: 16,
        textAlign: 'left',
        marginTop: 10
      },
      hintText: {
        fontSize: 16,
        textAlign: 'right',
      },

      image:{
        marginTop: 40,
        width: 70,
        height: 70
      }, 

      body:{
        marginTop: -40,
        textAlign: 'right',
        paddingLeft: 20,
        fontSize: 16,
      },

      button:{
        marginTop: 50,
        padding: 10,
        borderRadius: 25,
        width:'100%',
        height: 40,
        justifyContent: 'center',
        alignItems: 'center'
      }
});

export default styles;